---------------------------------------------------------------------
1. Content
---------------------------------------------------------------------

  * SmtListMC.zip
  * Z3Stuff.cs
  * AbstractChecker.cs
  * README.txt

---------------------------------------------------------------------
2. Instructions
---------------------------------------------------------------------

The "SmtListMC.zip" file contains a Java project along with the
examples from the paper.  Inside the project folder, there are some
helper scripts:

    (1) compile.sh         - compiles the Java project, and

    (2) run-simpleWhile.sh - runs the "simpleWhile" example from the
                             paper. 

The output of this stage is a C# source file, which, when compiled and
run, invokes the solver (Z3) to actually solve the model checking
problem in question.  The generated C# file simply uses the Z3 API to
create and solve a model-checking problem with
initial/transition/final conditions already discovered by the Java
project.  In order to compile this C# file you will need the other two
files: Z3Stuff.cs and AbstractChecker.cs, as well as a Z3 runtime
library.  We originally used Z3 version 2.0.3602.30840, so the might
not work with the latest Z3 version.
