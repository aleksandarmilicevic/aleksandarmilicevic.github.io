﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Z3;
using System.IO; 

namespace ZStuff
{
    public class Z3Stuff : IDisposable
    {
        public readonly Sort BOOL;
        public readonly Sort INT;
        public readonly Sort INT_ARRAY;
        public readonly Term INT_0;
        public readonly Term INT_1;

        protected readonly Context z3;
        protected readonly StreamWriter modelWriter;
        protected readonly bool writeModel;

        public Context Z3 { get { return z3; } }

        public Z3Stuff() : this(null) { }

        public Z3Stuff(string modelName)
        {
            this.writeModel = modelName != null;
            if (writeModel)
            {
                modelWriter = new StreamWriter(modelName + ".smt");
            }

            Config p = new Config();
            p.SetParamValue("MODEL", "true");

            if (z3 != null) 
                z3.Dispose();
            z3 = new Context(p);
            //z3.TraceToFile(modelName + "-trace.c");
            z3.OpenLog(modelName + "-model.z3");

            p.Dispose();

            z3.SetPrintMode(PrintMode.SmtlibFull);
            BOOL = z3.MkBoolSort();
            INT = z3.MkIntSort();
            INT_ARRAY = z3.MkArraySort(INT, INT);
            INT_0 = z3.MkNumeral(0, INT);
            INT_1 = z3.MkNumeral(1, INT);
        }

        public void Dispose()
        {
            z3.CloseLog();
            z3.Dispose();
            if (modelWriter != null)
                modelWriter.Close();
        }

        public Term Bool2Term(bool cond)
        {
            if (cond)
                return z3.MkTrue();
            else
                return z3.MkFalse();
        }

        public Term MkInt(int p)
        {
            return z3.MkNumeral(p, INT);
        }

        public Term MkBool(bool b)
        {
            if (b)
                return z3.MkTrue();
            else
                return z3.MkFalse();
        }

        public Sort MkArraySort(Sort domain, Sort range)
        {
            Sort arraySort = z3.MkArraySort(domain, range);
            WriteNewSort(arraySort);
            return arraySort;
        }

        public Sort MkEnumerationSort(string name, string[] enumNames, FuncDecl[] enumConsts, FuncDecl[] enumTesters)
        {
            Sort sort = z3.MkEnumerationSort(name, enumNames, enumConsts, enumTesters);
            WriteNewSort(sort);
            return sort;
        }


        public Sort MkTupleSort(string name, string[] fieldNames, Sort[] fieldTypes, out FuncDecl tupleCons, FuncDecl[] tupleProjections)
        {
            Sort sort = z3.MkTupleSort(name, fieldNames, fieldTypes, out tupleCons, tupleProjections);
            WriteNewSort(sort);
            return sort;
        }

        public Sort MkListSort(string name, Sort type, out FuncDecl listNil, out FuncDecl isListNil, out FuncDecl listCons, out FuncDecl isListCons, out FuncDecl listHead, out FuncDecl listTail)
        {
            Sort sort = z3.MkListSort(name, type, out listNil, out isListNil, out listCons, out isListCons, out listHead, out listTail);
            WriteNewSort(sort);
            return sort;
        }

        public Term MkConst(string name, Sort type)
        {
            Term term = z3.MkConst(name, type);
            WriteNewConst(name, type);
            return term;
        }

        public Term MkConst(FuncDecl cons)
        {
            Term term = z3.MkConst(cons);
            return term;
        }

        public FuncDecl MkFuncDecl(string name, Sort[] domain, Sort range)
        {
            FuncDecl func = z3.MkFuncDecl(name, domain, range);
            WriteNewFuncDec(name, domain, range); 
            return func;
        }

        public FuncDecl MkFuncDecl(string name, Sort domain, Sort range)
        {
            FuncDecl func = z3.MkFuncDecl(name, domain, range);
            WriteNewFuncDec(name, new Sort[] { domain }, range);
            return func;
        }

        public Term MkAnd(Term[] terms)
        {
            if (terms.Length == 0)
                return z3.MkTrue();
            if (terms.Length == 1)
                return terms[0];
            return z3.MkAnd(terms);
        }

        public Term MkOr(Term[] terms)
        {
            if (terms.Length == 0)
                return z3.MkFalse();
            if (terms.Length == 1)
                return terms[0];
            return z3.MkOr(terms);
        }

        public List<Term> allAssumptions = new List<Term>();

        public void AssertConstr(Term term)
        {
            WriteAssertion(term);
            allAssumptions.Add(term);
            z3.AssertCnstr(term);
        }

        public void FlushAllAssertions()
        {
            foreach (Term t in allAssumptions) {
                WriteAssertion(t);
                modelWriter.Flush();
            }
        }

        public void WriteNewSort(Sort sort)
        {
            modelWriter.WriteLine(":extrasorts ({0})", sort);
        }

        public void WriteAssertion(Term constraint)
        {
            modelWriter.WriteLine(":assumption {0}", constraint);
            modelWriter.Flush();
        }

        public void WriteNewConst(string name, Sort type)
        {
            modelWriter.WriteLine(":extrafuns (({0} {1}))", name, type.GetName());
        }

        public void WriteNewFuncDec(string name, Sort[] domains, Sort range)
        {
            string domainNames = "";
            foreach (Sort domain in domains) domainNames += domain.GetName() + " ";
            modelWriter.WriteLine(":extrafuns (({0} {1}{2}))", name, domainNames, range.GetName());
        }

        public void WriteComment(string comment)
        {
            foreach (string line in comment.Split('\n'))
            {
                modelWriter.WriteLine("; " + line);
            }
        }

        public void WriteBigComment(string comment)
        {
            modelWriter.WriteLine();
            modelWriter.WriteLine("; --------------------");
            WriteComment(comment);
            modelWriter.WriteLine("; --------------------");
            modelWriter.WriteLine();
        }

        public void WriteText(string text)
        {
            modelWriter.WriteLine(text);
        }

        public void FlushWritter()
        {
            modelWriter.Flush();
        }
    }
}
