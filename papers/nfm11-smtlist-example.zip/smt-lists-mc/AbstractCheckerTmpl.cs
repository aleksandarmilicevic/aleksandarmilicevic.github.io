﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ZStuff;
using Microsoft.Z3;

namespace smtmc
{
    public abstract class AbstractCheckerTmpl
    {
        protected Z3Stuff zStuff;
        protected Context z3;
        protected Model model;

        protected FuncDecl isSorted;

        protected Sort STATE_TUPLE;
        protected Sort STATES_LIST;

        protected FuncDecl[] tupleProjectionFuncs;
        protected FuncDecl tupleConsFunc;

        protected FuncDecl listNilFunc, isListNilFunc, listConsFunc, isListConsFunc, listHeadFunc, listTailFunc;
        protected FuncDecl checkTransitionFunc, checkPropertyFunc;

        protected Term statesList;
        
        protected String modelName = "softmc.smt";

        public AbstractCheckerTmpl() { }
        public AbstractCheckerTmpl(String modelName) 
        { 
            this.modelName = modelName;
            this.zStuff = new Z3Stuff(modelName);
            this.z3 = zStuff.Z3;
        }

        protected void InitVars()
        {
            statesList = zStuff.MkConst("states", STATES_LIST);
            InitExtraVars();
        }

        protected void InitSorts()
        {
            InitExtraSorts();

            // init states list
            STATES_LIST = zStuff.MkListSort("StateList", STATE_TUPLE, out listNilFunc, out isListNilFunc,
                out listConsFunc, out isListConsFunc, out listHeadFunc, out listTailFunc);
        }

        protected void InitFuncs()
        {
            isSorted = zStuff.MkFuncDecl("is_sorted", new Sort[] { zStuff.INT_ARRAY, zStuff.INT, zStuff.INT }, zStuff.BOOL);
            Term b_a = z3.MkBound(2, zStuff.INT_ARRAY);
            Term b_i = z3.MkBound(1, zStuff.INT);
            Term b_n = z3.MkBound(0, zStuff.INT);
            zStuff.AssertConstr(z3.MkForall(
                0,
                new Pattern[] { 
                    z3.MkPattern(new Term[] { z3.MkApp(isSorted, b_a, b_i, b_n) }),
                    z3.MkPattern(new Term[] { z3.MkApp(isSorted, b_a, z3.MkAdd(b_i, zStuff.INT_1), b_n) })
                },
                new Sort[] { zStuff.INT_ARRAY, zStuff.INT, zStuff.INT },
                new string[] { "a", "i", "len" },
                z3.MkEq(
                    z3.MkApp(isSorted, b_a, b_i, b_n),
                    z3.MkIte(
                        z3.MkLt(b_i, z3.MkSub(b_n, zStuff.INT_1)),
                        z3.MkAnd(
                            z3.MkLe(z3.MkArraySelect(b_a, b_i), z3.MkArraySelect(b_a, z3.MkAdd(b_i, zStuff.INT_1))),
                            z3.MkApp(isSorted, b_a, z3.MkAdd(b_i, zStuff.INT_1), b_n)),
                        z3.MkTrue()
                    )
                )
            ));
        }

        protected abstract void InitExtraSorts();
        protected abstract void InitExtraVars();
        protected abstract void AddInitialStateConstr();

        protected void AddStateTransitionConstr()
        {
            // define checkTransitionFunc
            checkTransitionFunc = zStuff.MkFuncDecl("check_tr", STATES_LIST, zStuff.BOOL);
            Term b_l1 = z3.MkBound(0, STATES_LIST);
            Term checkTransitionBody = GetStateTransitionCnstr(b_l1);
            zStuff.AssertConstr(z3.MkForall(
                0,
                new Pattern[] { z3.MkPattern(new Term[] { z3.MkApp(checkTransitionFunc, b_l1) }) },
                new Sort[] { STATES_LIST },
                new string[] { "l1" },
                z3.MkImplies(
                    z3.MkAnd(z3.MkApp(isListConsFunc, b_l1), z3.MkApp(isListConsFunc, z3.MkApp(listTailFunc, b_l1))),
                    z3.MkAnd(
                        checkTransitionBody,
                        z3.MkApp(checkTransitionFunc, z3.MkApp(listTailFunc, b_l1))
                    )
                )
            ));
            zStuff.AssertConstr(z3.MkApp(checkTransitionFunc, statesList));
        }

        protected abstract Term GetStateTransitionCnstr(Term listNode);

        protected virtual bool RunZ3()
        {
            z3.CheckAndGetModel(out model);
            String stats = z3.StatisticsToString();
            if (model != null)
            {
                Console.WriteLine("********* Counter example found ****************");
                //Console.WriteLine("Stats: " + stats);
                DispModel();
                model.Dispose();
                zStuff.Dispose();
                return false;
            }
            zStuff.Dispose();
            return true;
        }

        protected Term GetVarPre(Term listNode, FuncDecl varProjFunc)
        {
            return z3.MkApp(varProjFunc, z3.MkApp(listHeadFunc, listNode));
        }

        protected Term GetVarPost(Term listNode, FuncDecl varProjFunc)
        {
            return z3.MkApp(varProjFunc, z3.MkApp(listHeadFunc, z3.MkApp(listTailFunc, listNode)));
        }

        protected virtual void DispModel()
        {
            //model.Display(Console.Out);
            Console.WriteLine("Constants: ");
            foreach (FuncDecl fd in model.GetModelConstants())
            {
                string name = fd.GetDeclName();
                if (name.Equals("states"))
                    continue; // we'll do that separately
                Console.Write("  " + name + " = ");
                Console.WriteLine(EvalTerm(model, z3.MkConst(fd)));
            }

            Console.WriteLine("States list: ");
            FuncDecl[] tupleFields = z3.GetTupleFields(STATE_TUPLE);
            Term list = statesList;
            while (GetBoolTermVal(model.Eval(z3.MkApp(isListConsFunc, list))))
            {
                Term listNode = model.Eval(z3.MkApp(listHeadFunc, list));
                foreach (FuncDecl fd in tupleFields)
                {
                    Console.Write(fd.GetDeclName() + " = ");
                    Console.WriteLine(EvalTerm(model, z3.MkApp(fd, listNode)));
                }
                Console.WriteLine("-----------------------------------");
                list = model.Eval(z3.MkApp(listTailFunc, list));
            }
        }

        protected string EvalTerm(Model model, Term term)
        {
            Term termVal = model.Eval(term);
            FuncDecl fd = term.GetAppDecl();
            if (z3.GetRange(fd).ToString().StartsWith("array"))
            {
                StringBuilder sb = new StringBuilder();
                int len = z3.GetNumeralInt(model.Eval(z3.MkConst("N0", zStuff.INT)));
                for (int idx = 0; idx < len; idx++)
                {
                    Term arrElemVal = model.Eval(z3.MkArraySelect(term, zStuff.MkInt(idx)));
                    sb.Append(" ").Append(z3.GetNumeralInt(arrElemVal));
                }
                return "[" + sb.ToString().Substring(1) + "]";
            }
            else
            {
                return termVal.ToString();
            }
        }

        protected bool GetBoolTermVal(Term term)
        {
            return term.ToString().ToLower().Equals("true");
        }

        public bool Check()
        {
            zStuff.WriteBigComment("Extra sorts");
            InitSorts();
            InitFuncs();
            InitVars();

            zStuff.WriteBigComment("Initial state constraints");
            AddInitialStateConstr();

            zStuff.WriteBigComment("State transition constraints");
            AddStateTransitionConstr();

            return RunZ3();
        }
    }
}
