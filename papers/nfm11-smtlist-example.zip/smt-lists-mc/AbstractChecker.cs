﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ZStuff;
using Microsoft.Z3;

namespace smtmc
{
    public abstract class AbstractChecker
    {
        protected Z3Stuff zStuff;
        protected Context z3;
        protected Model model;

        protected Sort STATE_TUPLE;
        protected Sort STATES_LIST;

        protected FuncDecl[] tupleProjectionFuncs;
        protected FuncDecl tupleConsFunc;

        protected FuncDecl listNilFunc, isListNilFunc, listConsFunc, isListConsFunc, listHeadFunc, listTailFunc;
        protected FuncDecl checkTransitionFunc, checkPropertyFunc;

        protected Term statesList;
        
        protected String modelName = "softmc.smt";

        public AbstractChecker() { }
        public AbstractChecker(String modelName) { this.modelName = modelName; }

        protected void InitContext()
        {
            zStuff = new Z3Stuff(modelName);
            z3 = zStuff.Z3;
        }

        protected void InitVars()
        {
            statesList = zStuff.MkConst("states", STATES_LIST);
            InitExtraVars();
        }

        protected void InitSorts()
        {
            InitExtraSorts();

            // init states list
            STATES_LIST = zStuff.MkListSort("StateList", STATE_TUPLE, out listNilFunc, out isListNilFunc,
                out listConsFunc, out isListConsFunc, out listHeadFunc, out listTailFunc);
        }

        protected abstract void InitExtraSorts();
        protected abstract void InitExtraVars();
        protected abstract void AddInitialStateConstr();

        protected void AddStateTransitionConstr()
        {
            // define checkTransitionFunc
            checkTransitionFunc = zStuff.MkFuncDecl("check_tr", STATES_LIST, zStuff.BOOL);
            Term b_l1 = z3.MkBound(0, STATES_LIST);
            Term checkTransitionBody = GetStateTransitionCnstr(b_l1);
            zStuff.AssertConstr(z3.MkForall(
                0,
                new Pattern[] { z3.MkPattern(new Term[] { z3.MkApp(checkTransitionFunc, b_l1) }) },
                new Sort[] { STATES_LIST },
                new string[] { "l1" },
                z3.MkImplies(
                    z3.MkAnd(z3.MkApp(isListConsFunc, b_l1), z3.MkApp(isListConsFunc, z3.MkApp(listTailFunc, b_l1))),
                    z3.MkAnd(
                        checkTransitionBody,
                        z3.MkApp(checkTransitionFunc, z3.MkApp(listTailFunc, b_l1))
                    )
                )
            ));
            zStuff.AssertConstr(z3.MkApp(checkTransitionFunc, statesList));
        }

        protected abstract Term GetStateTransitionCnstr(Term listNode);

        protected void AddFinalPropertyConstr()
        {
            checkPropertyFunc = zStuff.MkFuncDecl("check_pr", STATES_LIST, zStuff.BOOL);
            Term b_l1 = z3.MkBound(0, STATES_LIST);
            Term terminationCond = GetTerminationCond(b_l1);
            Term assertion = z3.MkNot(GetAssertion(b_l1));
            zStuff.AssertConstr(z3.MkForall(
                0,
                new Pattern[] { z3.MkPattern(new Term[] { z3.MkApp(checkPropertyFunc, b_l1) }) },
                new Sort[] { STATES_LIST },
                new string[] { "l1" },
                z3.MkAnd(
                    z3.MkImplies(terminationCond, z3.MkApp(isListNilFunc, z3.MkApp(listTailFunc, b_l1))),
                    z3.MkIte(
                        z3.MkApp(isListNilFunc, z3.MkApp(listTailFunc, b_l1)),
                        z3.MkAnd(terminationCond, assertion),
                        z3.MkApp(checkPropertyFunc, z3.MkApp(listTailFunc, b_l1))
                    )
                )
            ));
            zStuff.AssertConstr(z3.MkApp(checkPropertyFunc, statesList));
        }

        protected abstract Term GetTerminationCond(Term list);
        protected abstract Term GetAssertion(Term list);

        protected virtual bool RunZ3()
        {
            z3.CheckAndGetModel(out model);
            String stats = z3.StatisticsToString();
            if (model != null)
            {
                Console.WriteLine("********* Counter example found ****************");
                //Console.WriteLine("Stats: " + stats);
                DispModel();
                model.Dispose();
                zStuff.Dispose();
                return false;
            }
            zStuff.Dispose();
            Console.WriteLine("========= VERIFIED =========");
            //Console.WriteLine("Stats: " + stats);
            return true;
        }

        protected virtual void DispModel()
        {
            model.Display(Console.Out);
        }

        public bool Check()
        {
            InitContext();

            zStuff.WriteBigComment("Extra sorts");
            InitSorts();
            InitVars();

            zStuff.WriteBigComment("Initial state constraints");
            AddInitialStateConstr();

            zStuff.WriteBigComment("State transition constraints");
            AddStateTransitionConstr();

            zStuff.WriteBigComment("Final property to satisfy");
            AddFinalPropertyConstr();

            return RunZ3();
        }
    }
}
